<section class="content-header">
    <h1>
        Cartera FNG
    </h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo base_url();?>home">Inicio</a></li>
        <li class="active">Cartera Fng</li>
    </ol>
</section>

<section class="content">

	<div class="box">
        <div class="box-body">
            </br></br></br></br>
            <div class="row">
                <div class="col-md-2"></div>
                <div class="col-md-8">
                    <div  class="row">
                        <div class="col-md-3">
                            <a href="<?php echo base_url();?>extrajudicial/clientesNuevos">
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-43.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>

                        <div class="col-md-3">
                            <a href="<?php echo base_url();?>extrajudicial/clientesDatoNuevo">
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-44.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>

                        <div class="col-md-3">
                            <a  href="<?php echo base_url();?>extrajudicial/valoradeudado" >
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-45.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>

                        <div class="col-md-3">
                            <a  href="<?php echo base_url();?>extrajudicial/clientesConacuerdodepago" >
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-46.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>
                    </div>
                    

                    <div  class="row">
                        <div class="col-md-3">
                            <a  href="<?php echo base_url();?>extrajudicial/misclientesVigentes" >
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-48.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>

                        <div class="col-md-3">
                            <a  href="<?php echo base_url();?>extraJudicial/busquedaAvanzada" >
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-49.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>

                        <div class="col-md-3">
                            <a  href="<?php echo base_url();?>extraJudicial/ObligacinesVendidas" >
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-66.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>

                        <div class="col-md-3">
                            <a  href="<?php echo base_url();?>extraJudicial/PazySalvo" >
                                <img src="<?php echo base_url();?>assets/botones/extrajudicial/botones-65.png" style=" width: 150px; height: auto;" id="logoHunter">
                            </a>
                        </div>

                    </div>
                </div>
                <div class="col-md-2"></div>
            </div>
            </br></br></br></br>
    	</div><!-- /.box-body -->
  	</div><!-- /.box -->
</section><!-- /.content -->