<section class="content-header">
    <h1>
        Cartera FNG - Clientes por valor adeudado
    </h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo base_url();?>home">Inicio</a></li>
        <li class="active">Clientes por valor adeudado</li>
    </ol>
</section>

<section class="content">
<a href="<?php echo base_url();?>extrajudicial" class="btn btn-primary"> &nbsp; Volver &nbsp;</a>
	<div class="box">
        <div class="box-body">
			<div  class="row">
		        <div class="col-sm-1"></div>
		        <div class="col-sm-2">
		            <a href="<?php echo base_url();?>extrajudicial/clientesmenosdedoce">
		                <img src="<?php echo base_url();?>assets/botones/Extrajudicial/botones-50.png" style=" width: 150px; height: auto;" >
		            </a>
		        </div>
		         <div class="col-sm-2">
		            <a href="<?php echo base_url();?>extrajudicial/clientesmasdedocemenosveinticinco">
		                <img src="<?php echo base_url();?>assets/botones/Extrajudicial/botones-51.png" style=" width: 150px; height: auto;" >
		            </a>
		        </div>
		         <div class="col-sm-2">
		            <a href="<?php echo base_url();?>extrajudicial/clientesmasdeveinticincomenoscincuenta">
		                <img src="<?php echo base_url();?>assets/botones/Extrajudicial/botones-52.png" style=" width: 150px; height: auto;">
		            </a>
		        </div>
		         <div class="col-sm-2">
		            <a href="<?php echo base_url();?>extrajudicial/clientesmasdecincuentamenoscien">
		                <img src="<?php echo base_url();?>assets/botones/Extrajudicial/botones-53.png" style=" width: 150px; height: auto;" >
		            </a>
		        </div>
		         <div class="col-sm-2">
		            <a href="<?php echo base_url();?>extrajudicial/clientesmascien">
		                <img src="<?php echo base_url();?>assets/botones/Extrajudicial/botones-54.png" style=" width: 150px; height: auto;" >
		            </a>
		        </div>
		        <div class="col-sm-1"></div>
		    </div>
    	</div><!-- /.box-body -->
  	</div><!-- /.box -->
</section><!-- /.content -->