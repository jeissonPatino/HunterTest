<section class="content-header">
    <h1>
        Cartera FNG
    </h1>
    <ol class="breadcrumb">
    	<li><a href="<?php echo base_url();?>home">Inicio</a></li>
        <li class="active">Cartera Fng</li>
    </ol>
</section>

<section class="content">
	<div class="box">
        <div class="box-body">
        	 </br></br></br></br>
        	<div  class="row">
                <div class="col-md-1">
                    &nbsp;
                </div>
        		<div class="col-md-2">
        			<a href="<?php echo base_url();?>cartera_fng/gestionJudicial">
        				<img src="<?php echo base_url();?>assets/botones/judicial/botones-73.png" style=" width: 100%; height: auto;" id="logoHunter">
        			</a>
        		</div>
        		<div class="col-md-2">
        			<a href="<?php echo base_url();?>cartera_fng/procesosIrrecuperables">
        				<img src="<?php echo base_url();?>assets/botones/judicial/botones-74.png" style=" width: 100%; height: auto;" id="logoHunter">
        			</a>
        		</div>
                <div class="col-md-2">
                    <a  href="<?php echo base_url();?>cartera_fng/procesosVendidos" >
                        <img src="<?php echo base_url();?>assets/botones/judicial/botones-75.png" style=" width: 100%; height: auto;" id="logoHunter">
                    </a>
                </div>
                <div class="col-md-2">
                    <a  href="<?php echo base_url();?>cartera_fng/busquedaAvanzada" >
                        <img src="<?php echo base_url();?>assets/botones/judicial/botones-77.png" style=" width: 100%; height: auto;" id="logoHunter">
                    </a>
                </div>
                <div class="col-md-2">
                    <a  href="<?php echo base_url();?>cartera_fng/PazySalvo" >
                        <img src="<?php echo base_url();?>assets/botones/judicial/botones-78.png" style=" width: 100%; height: auto;" id="logoHunter">
                    </a>
                </div>
                <div class="col-md-1">
                    &nbsp;
                </div>  
        	</div>
        	<br>
        	
             </br></br></br> 	 
    	</div><!-- /.box-body -->
  	</div><!-- /.box -->
</section><!-- /.content -->